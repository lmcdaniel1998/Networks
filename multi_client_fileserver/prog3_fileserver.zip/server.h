typedef struct argsInput {
	double errorPercent;
	int portNumber;
}argsInput;
